package hw1.hillclimbing;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;

/**
 * Hill Climbing Algorithm
 *
 * Definition
 *
 * Hill climbing is a mathematical optimization technique which
 * belongs to the family of local search. It is an iterative
 * algorithm that starts with an arbitrary solution to a problem,
 * then attempts to find a better solution by incrementally
 * changing a single element of the solution (Wiki Definition).
 *
 * Question
 *
 * Write a Hill-Climbing algorithm to find the maximum-value
 * of a function f, where f = |12 * one (v) - 160|. Here, v is the
 * input binary variable of 40 bits and the one counts the number
 * of ‘1’s in v. Set MAX =100, and thus reset algorithm 100 times
 * for the global maximum and print the found maximum-value for
 * each reset separated by comma.
 *
 *
 * Model of Algorithm
 *
 * As per the above question - Algorithm creates random bucket of
 * 40 bits of each size 40.
 *
 * For each generated 40 bits, the `i` th level of bit is flipped
 * with respect to the random selected bits which is used to compare
 * with other neighbours
 *
 * For each compare if better value is found, the current value is
 * updated till there is no such better value exists
 *
 *
 * The output values
 *
 * 320,320,320,320,320,320,320,320,320,320,320,320,320,320,320,320,
 * 320,320,320,320,320,320,320,320,320,320,320,320,320,320,320,320,
 * 320,320,320,320,320,320,320,320,320,320,320,320,320,320,320,320,
 * 320,320,320,320,320,320,320,320,320,320,320,320,320,320,320,320,
 * 320,320,320,320,320,320,320,320,320,320,320,320,320,320,320,320,
 * 320,320,320,320,320,320,320,320,320,320,320,320,320,320,320,320,
 * 320,320,320,320
 *
 *
 * @author Bhupendra Acharya
 * @email bacharya@uno.edu
 *
 */
public class HillClimber {

    /**
     * The number of iterations to run the scenario for hill climbing
     */
    private static final int MAX_ITERATIONS = 100;

    /**
     * The maximum population of bits to generate from a given input
     */
    private static final int MAX_STRINGS_POPULATION = 40;

    /**
     * The size of the given input
     */
    private static final int MAX_STRING_SIZE = 40;

    /**
     * The bucket of the bits string that are generated and populated
     * based on the flipping scenarios
     */
    private static List<List<Boolean>> bitsBucket;

    /**
     * Bucket filler
     * Randomly generate bits of 40 character long and store in bits bucket
     */
    static {
        bitsBucket = new ArrayList<>();
        for(int i=0; i < MAX_STRINGS_POPULATION; i++) {
            List<Boolean> getSingleLists = getRandomLists();
            bitsBucket.add(getSingleLists);
        }
    }

    public static void main(String[] args) {

        /* Choose a random string from the given bucket */
        final List<Boolean> randomStringVc = new LinkedList<>(getRandomStringVc());

        /* Evaluate the random bits selected function value*/
        int evaluateRandomVc = calculateFunctionValue(randomStringVc);

        /* Run and update the value while finding each better value that is greater
         * than the existing one
         */
        for(int i = 0; i < MAX_ITERATIONS; i++) {
            boolean toContinue = true;
            do {
                /* Create a new neighbours by flipping the original bit in ith level */
                List<List<Boolean>> newNeighbours = new LinkedList<>(getSingleBitFlippedNeighbours());
                /* Select the largest functional value from the neighbouring bucket and calculate the fitness */
                List<Boolean> largestVn = new LinkedList<>(getLargestFunctionValue(newNeighbours));
                int functionValueVn = calculateFunctionValue(largestVn);

                /* Given a higher value is found while climbing hill, update the higher value
                 * and continue this experience of search and update unless the previous value never
                 * higher
                 */
                if(evaluateRandomVc < functionValueVn) {
                    evaluateRandomVc = functionValueVn;
                } else {
                    toContinue = false;
                }
            } while (toContinue && i < MAX_ITERATIONS);

            /* Print values */
            System.out.print(evaluateRandomVc);
            if(i < 99) {
                System.out.print(",");
            }
        }
    }

    /**
     * Selects the random bits from the bucket
     * This is the initial for evaluate function which
     * will be used to compare with flipped neighbours
     * @return randomly selected bits
     */
    private static List<Boolean> getRandomStringVc() {
        int randomValue = getRandomIntValue(0, MAX_STRINGS_POPULATION-1);
        List<Boolean> randomStringVc = new ArrayList<>(bitsBucket.get(randomValue));
        return randomStringVc;
    }

    /**
     * Creates list of bits for a given string of 40 bit size
     * @return lists of randomly created bits of 40 size
     */
    private static List<Boolean> getRandomLists() {
        List<Boolean> temp = new LinkedList<>();
        for(int i = 0; i < MAX_STRING_SIZE; i++) {
            temp.add(getRandomFlags());
        }
        return temp;
    }

    /**
     * Calculate the # of ones present in the given bits
     * and gives it's functional value where f is represented
     * as f = | 12 X numberOfOnes - 160 |
     * @param lists the lists to find the functional value
     * @return integer value
     */
    private static int calculateFunctionValue(final List<Boolean> lists) {
        int numberOfOnes = Collections.frequency(lists, true);
        return Math.abs(12 * numberOfOnes - 160);
    }

    /**
     * Creates a bit bucket of 40 sizes of each length 40
     * The original created bitsBucket is flipped on
     * each `i` th level inorder to get the different neighbours
     * @return bit bucket
     */
    private static List<List<Boolean>> getSingleBitFlippedNeighbours() {
        List<List<Boolean>> temp = new LinkedList<>(bitsBucket);
        Collections.shuffle(temp);

        int pointer = 0;
        for(List<Boolean> a : temp) {
            a.set(pointer, !a.get(pointer));
            pointer += 1;
        }
        return temp;
    }

    /**
     * Fetches the largest functional value of bits from the given
     * bits bucket
     * @param lists bits bucket
     * @return bits that has largest functional value
     */
    private static List<Boolean> getLargestFunctionValue(final List<List<Boolean>> lists) {
        int largeValue = 0;
        List<Boolean> temp = new ArrayList<>();

        for(List<Boolean> a : lists) {
            int currentFunctionValue = calculateFunctionValue(a);
            if (currentFunctionValue > largeValue) {
                largeValue = currentFunctionValue;
                temp.clear();
                temp = new ArrayList<>(a);
            }
        }
        return temp;
    }

    /**
     * Randomly creates integer value with given minimum and maximum boundary
     * @param minimum minimum generating boundary
     * @param maximum maximum generating boundary
     * @return generated value between given boundary
     */
    private static int getRandomIntValue(final int minimum, final int maximum) {
        final Random random = new Random();
        int val = minimum + random.nextInt(maximum - minimum + 1);
        return val;
    }

    /**
     * Randomly creates boolean flags
     * The random generator picks a probability and fetches the
     * first half or last half as either true or false as randomly picked
     * @return boolean flag
     */
    private static boolean getRandomFlags() {
        final Random random = new Random();
        double randomProbabilityPoint = 0.1 + random.nextFloat() + 1.0;
        return randomProbabilityPoint > 0.3;
    }
}
