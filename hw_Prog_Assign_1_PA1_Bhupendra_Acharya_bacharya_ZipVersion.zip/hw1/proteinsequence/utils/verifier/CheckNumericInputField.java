package hw1.proteinsequence.utils.verifier;

import javax.swing.InputVerifier;
import javax.swing.JComponent;
import javax.swing.JTextField;

/**
 * Verifies the numeric input provided from Emulator
 * For each input the defined minimum and maximum field are checked
 * If the entry is not found in boundary, the form auto reset the text to empty
 *
 * Boundary Inputs for Emulator Form Text box options
 *
 * Population Size          <= 1 && >= 200
 * Cross Over Rate          <= 0.1 && >= 1.0
 * Target Value             <= 0 && >= -99
 * Elite Rate               <= 0.1 && >= 1.0
 * Mutation Rate            <= 0.1 && >= 1.0
 * Maximum Iteration        <=1 && >= 10000
 *
 */
public class CheckNumericInputField extends InputVerifier {

    /**
     * Text field for numeric entry
     */
    JTextField tf;

    /**
     * Minimum boundary
     */
    private double min;

    /**
     * Maximum boundary
     */
    private double max;

    public CheckNumericInputField(double min, double max) {
        this.min = min;
        this.max = max;
    }

    public CheckNumericInputField(int min, int max) {
        this.min = (double) min;
        this.max =  (double) max;
    }

    @Override
    public boolean verify(JComponent input) {
        this.tf = (JTextField) input;
        double numericValue = 0;

        try {
            numericValue = Double.parseDouble(tf.getText());
            /* Check if the input is between range */
            if(numericValue < this.min || numericValue > this.max) {
                tf.setText("");
            }
        } catch (NumberFormatException nfe) {
            tf.setText("");
        }
        return true;
    }
}
