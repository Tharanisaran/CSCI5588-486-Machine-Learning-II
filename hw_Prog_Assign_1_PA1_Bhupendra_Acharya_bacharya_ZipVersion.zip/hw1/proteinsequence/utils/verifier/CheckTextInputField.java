package hw1.proteinsequence.utils.verifier;

import javax.swing.InputVerifier;
import javax.swing.JComponent;
import javax.swing.JTextField;


import java.util.LinkedList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Verifies the input field for Protein has
 * the matched characters of either P, H, p, or h
 *
 * If found violation on tab out will reset the
 * input protein field box as empty
 */
public class CheckTextInputField extends InputVerifier {

    /**
     * Protein sequence acceptable characters hash set
     * Entry Set: P, H, p, h
     */
    private static final LinkedList<Character> proteinBucketAlphabets;

    static {
        proteinBucketAlphabets = new LinkedList<>();
        proteinBucketAlphabets.add('p');
        proteinBucketAlphabets.add('P');
        proteinBucketAlphabets.add('H');
        proteinBucketAlphabets.add('h');
    }

    @Override
    public boolean verify(JComponent input) {
        /**
         * Test box field for protein
         */
        JTextField tf = (JTextField) input;

        /**
         * Input provided by user
         */
        String inputValue;

        try {
            inputValue = tf.getText();
            /* Regex check if it is alphabets*/
            Pattern pattern= Pattern.compile("[a-zA-Z]+");
            Matcher m=pattern.matcher(inputValue);
            if(!m.matches()) {
                tf.setText("");
            } else {
                /**
                 * Given the entry has alphabets further check if the
                 * regex has only provided accepted protein bucket characters provided
                 */
                for (int i = 0; i < inputValue.length(); i++) {
                    Character current = inputValue.charAt(i);
                    if (!proteinBucketAlphabets.contains(current)) {
                        tf.setText("");
                        break;
                    }
                }
            }
        } catch (Exception ex) {
            return false;
        }
        return true;
    }
}
