package hw1.proteinsequence.utils.listener;

import hw1.proteinsequence.graphics.Constants;


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Button listener patterns listens the activities clicked in Button
 * and provide an intermediate call to core services "Bootstrap"
 *
 * The Bootstrap creates a simulation and gives back the response to
 * publish in the form to display the generated sequence
 */
public class ButtonEventListener implements ActionListener {
    @Override
    public void actionPerformed(ActionEvent e) {
        String command = e.getActionCommand();
        switch (command){
            case Constants.DRAW:
                break;
            case Constants.RESET:
                break;
            case Constants.STOP:
                break;
            default:
                throw new IllegalArgumentException("Unknown event requested!"
                        + e.getActionCommand());
        }
    }
}
