package hw1.proteinsequence.graphics;

import hw1.proteinsequence.core.Bootstrap;
import hw1.proteinsequence.utils.listener.ButtonEventListener;
import hw1.proteinsequence.utils.verifier.CheckNumericInputField;
import hw1.proteinsequence.utils.verifier.CheckTextInputField;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import org.apache.commons.lang3.StringUtils;


import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.HashMap;
import java.util.Map;

/**
 * Emulator - The main class which creates a form
 * and displays the events requested
 *
 * The mediator between core services for HP Lattice Model
 * and User Input Experience
 */
public class Emulator extends EmulatorBase {

    /**
     * Captures the input form request to process the data
     */
    Bootstrap bootstrap;

    private Emulator () {
        prepareEvent();
    }

    public static void main(String[] args) {
        Emulator emulator = new Emulator();
        SwingUtilities.invokeLater(new Runnable(){
            public void run(){
                emulator.displayEvent();
            }
        });
    }

    /**
     * Initialize frame, layout and window settings
     */
    private void initializeMainFrame() {
        mainFrame = new JFrame(Constants.FRAME_TITLE);
        mainFrame.setSize(Constants.FRAME_WIDTH, Constants.FRAME_HEIGHT);
        mainFrame.setLayout(new GridLayout(5, 5));
        mainFrame.setResizable(false);

        headerLabel = new JLabel("", JLabel.CENTER);

        mainFrame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent windowEvent) {
                System.exit(0);
            }
        });
    }

    /**
     * Creates Panels and sub panels for form input displays
     */
    private void initializePanels() {
        GridLayout controlPanelGridLayout = new GridLayout(8, 4);
        GridLayout subPanelGridLayout = new GridLayout(1,1, 1,1);
        /* Main Panel */
        controlPanel = new JPanel(controlPanelGridLayout);

        /* Sub Panels */
        firstPanel = new JPanel(subPanelGridLayout);
        secondPanel = new JPanel(subPanelGridLayout);
        thirdPanel = new JPanel(subPanelGridLayout);
        fourthPanel = new JPanel(new FlowLayout());
        drawPanel = new JPanel(subPanelGridLayout);
    }

    /**
     * Create an input field text box
     *
     * Input fields
     *
     * Protein Input - The length of the Protein
     * Population Size - The number of population size to generate
     * Elite Rate Input - Best fit population rate
     * Cross Over Rate - The crossing percentile
     * Mutation Rate - Mutation percentile
     * Target Value Rate - The best scenario protein fitness value
     * Maximum Iteration - The number of times to run the loop
     */
    private void initializeInput() {
        this.inputProteinText = new JTextField(35);
        this.populationSizeField = new JTextField(5);
        this.eliteRateField = new JTextField(5);
        this.crossOverRate = new JTextField(5);
        this.mutationRate = new JTextField(5);
        this.targetValueField = new JTextField(5);
        this.maximumIterationField = new JTextField(5);
    }

    /**
     * Displays input form box
     */
    private void displayInputForm() {
        inputFormValues = new HashMap<>();

        /**
         * Adds Population size to the form
         */
        firstPanel.add(new JLabel(Constants.POPULATION_SIZE_LABEL));
        firstPanel.add(populationSizeField);
        populationSizeField.setInputVerifier(new CheckNumericInputField(
                Constants.MIN_POPULATION_SIZE, Constants.MAX_POPULATION_SIZE));
        inputFormValues.put(Constants.INPUT_POPULATION_SIZE_VALUE, populationSizeField);

        /**
         * Adds elite rate to the form
         */
        firstPanel.add(new JLabel(Constants.ELITE_RATE_LABEL));
        firstPanel.add(eliteRateField);
        eliteRateField.setInputVerifier(new CheckNumericInputField(
                Constants.MIN_RATE, Constants.MAX_RATE));
        inputFormValues.put(Constants.INPUT_ELITE_RATE, eliteRateField);

        /**
         * Adds Cross Over rate to the form
         */
        secondPanel.add(new JLabel(Constants.CROSS_OVER_RATE_LABEL));
        secondPanel.add(crossOverRate);
        crossOverRate.setInputVerifier(new CheckNumericInputField(
                Constants.MIN_RATE, Constants.MAX_RATE));
        inputFormValues.put(Constants.INPUT_CROSS_OVER_RATE, crossOverRate);

        /**
         * Adds mutation rate to the form
         */
        secondPanel.add(new JLabel(Constants.MUTATION_RATE_LABEL));
        secondPanel.add(mutationRate);
        mutationRate.setInputVerifier(new CheckNumericInputField(
                Constants.MIN_RATE, Constants.MAX_RATE));
        inputFormValues.put(Constants.INPUT_MUTATION_RATE, mutationRate);

        /**
         * Adds target value to the form
         */
        thirdPanel.add(new JLabel(Constants.TARGET_VALUE_LABEL));
        thirdPanel.add(targetValueField);
        targetValueField.setInputVerifier(new CheckNumericInputField(
                Constants.MIN_TARGET_VALUE, Constants.MAX_TARGET_VALUE));
        inputFormValues.put(Constants.INPUT_TARGET_VALUE, targetValueField);

        /**
         * Adds maximum iteration to the form
         */
        thirdPanel.add(new JLabel(Constants.MAXIMUM_ITERATION_LABEL));
        thirdPanel.add(maximumIterationField);
        maximumIterationField.setInputVerifier(new CheckNumericInputField(
                Constants.MIN_ITERATION_SIZE, Constants.MAX_ITERATION_SIZE));
        inputFormValues.put(Constants.INPUT_ITERATION, maximumIterationField);

        /**
         * Adds Protein Field to the form
         */
        fourthPanel.add(new JLabel(Constants.INPUT_PROTEIN_LABEL));
        fourthPanel.add(inputProteinText);
        inputProteinText.setInputVerifier(new CheckTextInputField());
        inputFormValues.put(Constants.INPUT_PROTEIN_VALUE, inputProteinText);

        /**
         * Add sub panel to the main panel
         */
        controlPanel.add(fourthPanel);
        controlPanel.add(firstPanel);
        controlPanel.add(secondPanel);
        controlPanel.add(thirdPanel);

        mainFrame.add(controlPanel);
        mainFrame.pack();
        mainFrame.setVisible(true);
    }

    /**
     * Prepare an event of initializing main frame, panels, inputs and
     * form as whole
     */
    public void prepareEvent(){
        initializeMainFrame();
        initializePanels();
        initializeInput();
        displayInputForm();
    }

    /**
     * Display an event of the form - Action listener
     */
    public void displayEvent() {
        headerLabel.setText(Constants.GENERATE_PROTEIN_FOLD_TITLE);

        /**
         * Adds button: Draw, Reset, and Stop
         */
        drawButton = new JButton(Constants.DRAW);
        resetButton = new JButton (Constants.RESET);
        stopButton = new JButton (Constants.STOP);

        /**
         * Set action command to fetch the request from
         * button selected
         */
        drawButton.setActionCommand(Constants.DRAW);
        resetButton.setActionCommand(Constants.RESET);
        stopButton.setActionCommand(Constants.STOP);

        /**
         * Set action listner to perform the request
         */
        drawButton.addActionListener(new ButtonEventListener());
        resetButton.addActionListener(new ButtonEventListener());
        stopButton.addActionListener(new ButtonEventListener());

        /**
         * Add buttons to the panels and from display
         */
        drawPanel.add(drawButton);
        drawPanel.add(resetButton);
        drawPanel.add(stopButton);

        controlPanel.add(drawPanel);
        mainFrame.pack();
        mainFrame.setVisible(true);
    }

    /**
     * Checks if the radio button draw, reset and stop should be
     * enabled or not
     * The state of enable / disable depends if the form is fully
     * filled on the input parameter provided, else the radio button
     * is disabled
     * @return true / false
     */
    public boolean doEnableRadio() {
        for(Map.Entry entry: inputFormValues.entrySet()) {
            JTextField jf = (JTextField) entry.getValue();
            if(StringUtils.isBlank(jf.getText())) {
                return false;
            }
        }
        return true;
    }
}
