package hw1.proteinsequence.graphics;


import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;


import java.awt.LayoutManager;
import java.util.Map;

/**
 * Base set up for Emulator
 */
public abstract class EmulatorBase implements IEvents {

    /**
     * The mainframe of the emulator
     */
    protected JFrame mainFrame;

    /**
     * The Generic title for display of events Ex. Draw, Stop, Pause
     */
    protected JLabel headerLabel;

    /**
     * Collections of JPanel inside a mainframe that displays as
     * control events
     */

    protected static Map<JPanel, LayoutManager> panels;

    protected JPanel controlPanel;
    protected JPanel firstPanel;
    protected JPanel secondPanel;
    protected JPanel thirdPanel;
    protected JPanel fourthPanel;
    protected JPanel drawPanel;


    /**
     * The input text field corresponding to the input fields
     */

    protected Map<String, JTextField> inputFormValues;

    protected JTextField inputProteinText;
    protected JTextField populationSizeField;
    protected JTextField eliteRateField;
    protected JTextField crossOverRate;
    protected JTextField mutationRate;
    protected JTextField targetValueField;
    protected JTextField maximumIterationField;

    /**
     * The actions button Ex. Draw, Pause or Reset the canvas drawings
     */

    protected static Map<JButton, String> actionsButtons;

    protected JButton drawButton;
    protected JButton resetButton;
    protected JButton stopButton;

    @Override
    public void prepareEvent() {

    }

    @Override
    public void displayEvent() {

    }
}
