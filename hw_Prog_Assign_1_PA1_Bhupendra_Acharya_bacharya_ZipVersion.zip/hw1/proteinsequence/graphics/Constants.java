package hw1.proteinsequence.graphics;

public class Constants {

    /* Dimensions */
    public static final int FRAME_WIDTH = 1000;
    public static final int FRAME_HEIGHT = 625;

    /* Labels */

    /* Display Title Main Frame*/
    public static final String FRAME_TITLE = "HP Lattice Model - Fitness Sequence";
    /* Display Title Generating Protein Fold */
    public static final String GENERATE_PROTEIN_FOLD_TITLE = "Generating in progress ... ";

    /* Input Labels*/
    public static final String POPULATION_SIZE_LABEL = "Population Size : ";
    public static final String ELITE_RATE_LABEL = "Elite Rate : ";
    public static final String CROSS_OVER_RATE_LABEL = "Cross Over Rate : ";
    public static final String MUTATION_RATE_LABEL = "Mutation Rate : ";
    public static final String TARGET_VALUE_LABEL = "Target Value : ";
    public static final String MAXIMUM_ITERATION_LABEL = "Maximum Iteration : ";
    public static final String INPUT_PROTEIN_LABEL = "Input Protein : ";

    public static final String INPUT_PROTEIN_VALUE = "inputProteinText";
    public static final String INPUT_POPULATION_SIZE_VALUE = "populationSizeField";
    public static final String INPUT_ELITE_RATE = "eliteRateField";
    public static final String INPUT_CROSS_OVER_RATE = "crossOverRate";
    public static final String INPUT_MUTATION_RATE = "mutationRate";
    public static final String INPUT_TARGET_VALUE = "targetValueField";
    public static final String INPUT_ITERATION = "maximumIterationField";

    /* Buttons */
    public static final String DRAW = "Draw";
    public static final String RESET = "Reset";
    public static final String STOP = "Stop";

    /* Input Validators Max and Min Size */
    public static final int MIN_POPULATION_SIZE = 1;
    public static final int MAX_POPULATION_SIZE = 200;

    public static final double MIN_RATE = 0.1;
    public static final double MAX_RATE = 1.0;

    public static final int MIN_TARGET_VALUE = -99;
    public static final int MAX_TARGET_VALUE = 0;

    public static final int MIN_ITERATION_SIZE = 1;
    public static final int MAX_ITERATION_SIZE = 1000000;
}
