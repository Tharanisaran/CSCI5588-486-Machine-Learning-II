package hw1.proteinsequence.graphics;

/**
 * Emulator events are form generate
 */
public interface IEvents {
    /**
     * Associate and prepare for form event to generate
     */
    void prepareEvent();

    /**
     * Displays the aggregated form information
     */
    void displayEvent();
}
