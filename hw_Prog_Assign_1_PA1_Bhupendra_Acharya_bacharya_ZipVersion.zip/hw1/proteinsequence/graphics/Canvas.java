package hw1.proteinsequence.graphics;

import javax.swing.JPanel;


import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.util.HashMap;

/**
 * Canvas is the box display for fetching the core request
 * to display the generated sequences
 *
 * This is an incomplete task
 */
public class Canvas extends JPanel {

    private static final int WIDTH = 600;
    private static final int LENGTH = 600;

    public Canvas() {

    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        setBackground(Color.WHITE);
    }

    void draw(Graphics g, HashMap<Point, Character> sequence) {

        if(sequence == null) {
            throw new IllegalArgumentException("Sequence can not be null");
        }

        /**
         * Incomplete task
         * Fetch and draw the sequence when user hits "Draw" button in UI
         */

        // g.drawCrossAndMutation()
    }
}
