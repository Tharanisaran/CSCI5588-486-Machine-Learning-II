package hw1.proteinsequence.core.populate;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * Creates self avoiding walk
 *
 * For a given sequence create walk in canvas
 * such a way that the collision of the points does
 * no occur
 */
public class GenerateSelfAvoidingWalk {

    /**
     * Population size
     */
    private int populationSize;

    /**
     * Input protein
     */
    private int inputSize;

    /**
     * Input protein List display
     */
    private List<Character> input = new ArrayList<>();

    public GenerateSelfAvoidingWalk(List<Character> input,
                                    int populationSize) {
        this.input = input;
        this.populationSize = populationSize;
        this.inputSize = input.size();
    }

    /**
     * Fetch a pool of self avoiding walk sequences
     * from the user input population size
     *
     * For each created sequences calculates
     * fitness associated
     * @return GeneratedSequence with corresponding FitnessValue
     */
    public Map<Character[][], Integer> getGeneratedPopulation() {
        Map<Character[][], Integer> tempMap = new HashMap<>();
        for(int i=0; i < populationSize; i++) {
            Character[] [] temp = this.drawHPLatticeSAW();
            int fitness = calculateFitness(temp);
            if(!tempMap.containsKey(temp)) {
               tempMap.put(temp, fitness);
           /* Ensure the population size gets generated in case of duplicate key found*/
            } else {
               i -= 1;
           }
       }
       return tempMap;
    }

    /**
     * Creates a singl self avoiding walk sequences
     * @return Drawn single self avoiding walk sequence
     */
    private Character[][] drawHPLatticeSAW() {
        boolean [][] visited  = new boolean[3 * inputSize] [3 * inputSize];
        Character [][] hpLattice = new Character [3 * inputSize] [3 * inputSize];

        int x = this.input.size() / 2;
        int y = this.input.size() / 2;

        visited[x] [y] = true;
        hpLattice [x] [y] = input.get(0);
        for(int i=1; i < this.input.size(); i++) {
            while (true) {
                int random = getRandomNumber();
                if (random <= 25 && !visited[x - 1][y]) {
                    x--;
                    break;
                } else if (random > 25 && random <= 50 && !visited[x + 1][y]) {
                    x++;
                    break;
                } else if (random > 50 && random <= 75 && !visited[x][y - 1]) {
                    y--;
                    break;
                } else if (random > 75 && !visited[x][y + 1]) {
                    y++;
                    break;
                }
            }
            hpLattice[x][y] = input.get(i);
            visited[x][y] = true;
        }
        return hpLattice;
    }

    /**
     * Calculates fitness for the provided sequence
     * @param sawHPLattice
     * @return fitness value
     */
    private int calculateFitness(Character[] [] sawHPLattice) {
        int topologicalNeigbour = 0;
        for(int row=0; row < sawHPLattice.length; row++) {
            for(int column=0; column < sawHPLattice[row].length; column++) {
                Character ch = sawHPLattice[row][column];
                for(int compareColumn = column+1; compareColumn < sawHPLattice.length;
                        compareColumn++) {
                    if(ch.equals(sawHPLattice[row][compareColumn])
                            && isHydroPhobic(ch)
                            && isAdjacentAndUnitDistance(row, column, row, compareColumn)) {
                        topologicalNeigbour -= 1;
                    }
                }
            }
        }
        return topologicalNeigbour;
    }

    /**
     * Check if the given points are adjacent and are unit distance apart
     * The logic of calculating fitness value
     * @param x1 Co-ordinates
     * @param y1 Co-ordinates
     * @param x2 Co-ordinates
     * @param y2 Co-ordinates
     * @return boolean flag
     */
    private boolean isAdjacentAndUnitDistance(int x1, int y1, int x2, int y2) {
        return ((Math.pow(Math.abs(x2 - x1), 2) +
                Math.pow(Math.abs(y2 - y1), 2))
                == 1);
    }

    /**
     * Fetch random number between 0 and 100
     * @return random number
     */
    private int getRandomNumber() {
        Random num = new Random();
        return 0 + num.nextInt(100);
    }

    /**
     * Check if the provided sequence is hydrophobic or not
     * @param ch Character input P or H
     * @return boolean flag
     */
    public static boolean isHydroPhobic(Character ch) {
        return ch.equals("H");
    }
}
