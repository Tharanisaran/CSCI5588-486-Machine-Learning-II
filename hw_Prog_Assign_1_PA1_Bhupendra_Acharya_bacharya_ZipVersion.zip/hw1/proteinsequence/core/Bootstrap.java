package hw1.proteinsequence.core;

import hw1.proteinsequence.core.populate.GenerateSelfAvoidingWalk;
import hw1.proteinsequence.core.selectandapply.CrossAndMutation;


import java.util.ArrayList;

/**
 * Bootstrap initializes the core services
 * to generated the sequence as per the user
 * request form form events
 */
public class Bootstrap {

    /**
     * Self avoiding walk
     */
    private GenerateSelfAvoidingWalk generateSelfAvoidingWalk;

    /**
     * Apply select, cross over and mutate
     */
    private CrossAndMutation crossAndMutation;

    /**
     * Form input values
     */
    private String protein;
    private int populationSize;
    private double eliteRate;
    private double crossOverRate;
    private double mutationRate;
    private int targetValue;
    private int maximumIteration;

    public Bootstrap(String protein,
                     int populationSize,
                     double eliteRate,
                     double crossOverRate,
                     double mutationRate,
                     int targetValue,
                     int maximumIteration) {

        this.protein = protein;
        this.populationSize = populationSize;
        this.eliteRate = eliteRate;
        this.crossOverRate = crossOverRate;
        this.mutationRate = mutationRate;
        this.targetValue = targetValue;
        this.maximumIteration = maximumIteration;

        this.generateSelfAvoidingWalk = getGenerateSelfAvoidingWalk();
    }

    /**
     * Create self avoiding walk
     * @return created sequences
     */
    public GenerateSelfAvoidingWalk getGenerateSelfAvoidingWalk() {
        this.protein = protein.toUpperCase();
        ArrayList<Character> charList = new ArrayList<Character>();
        for(int i=0; i < this.protein.length(); i++) {
            charList.add(protein.charAt(i));
        }
        return new GenerateSelfAvoidingWalk(charList, this.populationSize);
    }

    /**
     * Fetch select, apply, cross over and mutate information
     * @return cross over and mutated info
     */
    public CrossAndMutation getCrossAndMutationSequence() {
        return new CrossAndMutation(
                this.generateSelfAvoidingWalk,
                this.eliteRate,
                this.mutationRate,
                this.targetValue,
                this.populationSize
        );
    }
}
