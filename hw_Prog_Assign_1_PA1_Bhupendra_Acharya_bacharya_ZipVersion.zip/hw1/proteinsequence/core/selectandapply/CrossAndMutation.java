package hw1.proteinsequence.core.selectandapply;

import hw1.proteinsequence.core.populate.GenerateSelfAvoidingWalk;


import java.awt.Point;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.TreeMap;

/**
 * Select cross and mutate
 *
 * The functionality of cross and mutate selects the randomly generated
 * Self Avoiding Walk population and creates a elite group. Elite group
 * members are high energy function proteins. For the given elite rate to
 * be selected during mutation, the cross over check is applied and mutation
 * is applied for any applicable sequences
 *
 */
public class CrossAndMutation {

    /**
     * Elite Rate
     * Selects the percentile of bucket from generated popualted
     * with respect to fitness found
     */
    double eliteRate;

    /**
     * Mutates the population to the provided rate
     */
    double mutationRate;

    /**
     * The target value which is to be generated as best case scenario
     */
    double targetValue;

    /**
     * The population of the sequence
     */
    int population;

    /**
     * The total pool of sequence which is a bucket to hold the
     * self avoiding walk generated seqquence
     */
    private Map<Character[][], Integer> pool = new HashMap<>();

    /**
     * Self avoiding walk sequences
     */
    GenerateSelfAvoidingWalk generateSelfAvoidingWalk;

    public CrossAndMutation(GenerateSelfAvoidingWalk generateSelfAvoidingWalk,
                            double eliteRate,
                            double mutationRate,
                            double targetValue,
                            int population) {
        this.generateSelfAvoidingWalk = generateSelfAvoidingWalk;
        this.eliteRate = eliteRate;
        this.mutationRate = mutationRate;
        this.targetValue = targetValue;
        this.population = population;
    }

    /**
     * Create a pool of elite by sorting best on fitness
     * @return elite pool
     */
    public Map<Character[][], Integer> elitePool() {
        SortMap map = new SortMap(this.pool);
        Map treeMap = new TreeMap(map);
        treeMap.putAll(this.pool);
        return treeMap;
    }

    /**
     * For a given sequences to cross check if that can be crossed or not
     * If applicable do cross over
     *
     * Method purposely exposed public to "Bootstrap" to be utilized by Canvas
     * of Emulator for showing the random generated accepted fitness sequences
     *
     */
    public void tryCrossOverAndMutate() {
        /* First sequence */
        Map<Point, Character> seq1 = new HashMap<>();

        /* Second sequence */
        Map<Point, Character> seq2 = new HashMap<>();

        int sizeOfSequence = seq1.size();

        /* select randomly from elite group */
        Random rand = new Random();
        int randomValue = 0 + rand.nextInt((int) (eliteRate * population));

        int randomPopulationSelection = 0 + rand.nextInt(population);

        /* Selected random elite */
        Map<Character[][], Integer> selectedElite = new HashMap<>(elitePool().get(randomValue));

        /* Selected random non-elite */
        Map<Character[][], Integer> selectedRandomFromPopulation = new HashMap<>(pool.get(randomValue));

        /* Bucket conversion for Point co-ordinates */
        seq1 = processSequence(selectedElite);
        seq2 = processSequence(selectedRandomFromPopulation);

        /* Get boundary provided entries */
        Map<Point, Character> seq1Half = new HashMap<>(getEntries(0, sizeOfSequence/2, seq1));
        Map<Point, Character> seq2half = new HashMap<>(getEntries(sizeOfSequence/2, sizeOfSequence, seq2));

        /* Apply mutation if can be crossed */

        if(canCross(seq1Half, seq2half)) {
            mutate(seq1Half, seq2half);
        }

    }

    /**
     * Check if two sequences can be crossed or not
     * @param seq1Half First sequence
     * @param seq2half Second sequence
     * @return boolean
     */
    private static boolean canCross(Map<Point, Character> seq1Half, Map<Point, Character> seq2half) {
        for (Map.Entry<Point, Character> firstHalf: seq1Half.entrySet()) {
            for(Map.Entry<Point, Character> secondHalf: seq2half.entrySet()) {
                if(secondHalf.getValue().equals(firstHalf.getKey())) {
                    return false;
                }
            }
        }
        return true;
    }


    /**
     * Mutate given sequences by picking Degress: 90, 180 or 270
     * @param seq1Half First Sequence
     * @param seq2half Second sequence
     */
    private void mutate(Map<Point, Character> seq1Half, Map<Point, Character> seq2half) {
        /* Only sequences which can be crossed should be given as to mutate */
        if(!canCross(seq1Half, seq2half)) {
            throw new IllegalArgumentException("2 Half sequences to be mutated should " +
                    "be able to cross during mutation forming !");
        } else {
            boolean toContinue = true;

            /* Create a new bucket combining first and second sequences */
            Map<Point, Character> crossedSequence = new HashMap<>();
            crossedSequence.putAll(seq1Half);
            crossedSequence.putAll(seq2half);

            /* Rotate the sequence for best finess level */
            Character[] [] toRotate = new Character [crossedSequence.size()] [];
            Rotate rotate = new Rotate(toRotate);
            Character[][] rotatedSequence = rotate.getRotatedMatrix();
        }
    }

    /**
     * Fetch new bucket based on minimum and maximum boundary
     *
     * This is used when a sequence is divided into first half or second half
     * with picked elite and non elite during select and apply
     *
     * @param min minimum range
     * @param max maximum range
     * @param fromEntries sequence
     * @return Fetches new bucket
     */
    private Map<Point, Character> getEntries(int min, int max, Map<Point, Character> fromEntries) {
        Map<Point, Character> temp = new HashMap<>();
        int counter = 0;
        for(Map.Entry<Point, Character> entry: fromEntries.entrySet()) {
            if(counter >= min && counter < max) {
                temp.put(entry.getKey(), entry.getValue());
            }
        }
        return temp;
    }

    /**
     * Process sequence creates a new bucket as conversion from
     * Character array to Point
     * @param sequence Map of Character array and fitness
     * @return Map of Point co-ordinates and characters (H or P)
     */
    private Map<Point, Character> processSequence (Map<Character[][], Integer> sequence) {
        Map<Point, Character> temp = new HashMap<>();
        for(Character[][] a: sequence.keySet()) {
            for(int i=0; i < a.length; i++) {
                for(int j=0; j < a[i].length; j++) {
                    if(a[i][j].charValue() == 'H'
                            || a[i][j].charValue() == 'h'
                            || a[i][j].charValue() == 'p'
                            || a[i][j].charValue() == 'P') {
                        temp.put(new Point(i,j), a[i][j]);
                    }
                }
            }
        }
        return temp;
    }

    /**
     * Sort Map sorts the provided map based on fitness values
     */
    private class SortMap implements Comparator {
        Map map;

        public SortMap (Map map) {
            this.map = map;
        }

        @Override
        public int compare(Object o1, Object o2) {
            return ((Integer) map.get(o2)).compareTo((Integer)map.get(o2));
        }
    }
}
