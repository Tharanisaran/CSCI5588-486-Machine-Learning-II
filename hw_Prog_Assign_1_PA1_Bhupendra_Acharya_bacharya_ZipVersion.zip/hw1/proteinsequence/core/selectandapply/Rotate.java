package hw1.proteinsequence.core.selectandapply;

/**
 * Rotate a given sequence during mutation
 */
public class Rotate {

    /**
     * Degrees to rotate
     */
    public static DEGREE degree;

    /**
     * Input sequence
     */
    public Character[] [] input;

    public enum DEGREE {
        NINETY(90),
        ONE_EIGHTY(180),
        TWO_SEVENTY(270);

        private final int value;

        private DEGREE(int value) {
            this.value = value;
        }

        public int getValue() {
            return this.value;
        }

    }

    public Rotate (Character[][] input) {
        this.input = input;
    }

    public Rotate(Character[][] input, DEGREE degree){
        this.input = input;
        this.degree = degree;
    }

    /**
     * Rotated 90 degree
     * @param matrix input sequence
     * @return rotated input sequence
     */
    public Character[][] rotateNinetyDegree(Character[] [] matrix) {
        this.transpose(matrix);
        this.horizontalReflection(matrix);
        return matrix;
    }

    /**
     * Rotated 180 degree
     * @param matrix input sequence
     * @return rotated input sequence
     */
    public Character[][] rotateOneEightyDegree(Character[] [] matrix) {
        this.horizontalReflection(matrix);
        this.verticalReflection(matrix);
        return matrix;
    }

    /**
     * Rotated 270 degree
     * @param matrix input sequence
     * @return rotated input sequence
     */
    public Character[][] rotateTwoSeventyDegree(Character[][] matrix) {
        this.transpose(matrix);
        this.verticalReflection(matrix);
        return matrix;
    }

    private Character[][] transpose(Character[] [] matrix) {
        int row = matrix[0].length;
        int column = matrix.length;

        Character[] [] temp = new Character[row][column];

        for(int i=0; i < matrix.length; i++) {
            for(int j=0; j < matrix[i].length; j++) {
                temp[j][i] = matrix[i] [j];
            }
        }
        return temp;
    }

    private void horizontalReflection(Character[] [] matrix) {
        int size = matrix.length;
        int rowLength = matrix[0].length;

        for(int i=0; i < size/2; i++) {
            for(int j=0; j < rowLength; j++) {
                Character temp = matrix[i][j];
                matrix[i] [j] = matrix[rowLength - i + 1] [j];
                matrix[rowLength - i + 1] [j] = temp;
            }
        }
    }

    private void verticalReflection(Character[] [] matrix) {
        int size = matrix.length;
        int rowLength = matrix[0].length;

        for(int i=0; i < size/2; i++) {
            for(int j=0; j < rowLength; j++) {
                Character temp = matrix[i][j];
                matrix[i] [j] = matrix[j] [rowLength - i + 1];
                matrix[j] [rowLength - i + 1] = temp;
            }
        }
    }

    /**
     * Fetch rotated matrix
     * @return rotated matrix
     */
    public Character[] [] getRotatedMatrix() {
        return this.input;
    }
}
